if(!window.dash_clientside) {window.dash_clientside = {};}
window.dash_clientside.clientside = {
    display: function (value) {
        return 'Client says "' + value + '"';
    }
}
