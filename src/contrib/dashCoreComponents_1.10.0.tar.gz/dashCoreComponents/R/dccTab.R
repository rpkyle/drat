# AUTO GENERATED FILE - DO NOT EDIT

dccTab <- function(children=NULL, id=NULL, label=NULL, value=NULL, disabled=NULL, disabled_style=NULL, disabled_className=NULL, className=NULL, selected_className=NULL, style=NULL, selected_style=NULL, loading_state=NULL) {
    
    props <- list(children=children, id=id, label=label, value=value, disabled=disabled, disabled_style=disabled_style, disabled_className=disabled_className, className=className, selected_className=selected_className, style=style, selected_style=selected_style, loading_state=loading_state)
    if (length(props) > 0) {
        props <- props[!vapply(props, is.null, logical(1))]
    }
    component <- list(
        props = props,
        type = 'Tab',
        namespace = 'dash_core_components',
        propNames = c('children', 'id', 'label', 'value', 'disabled', 'disabled_style', 'disabled_className', 'className', 'selected_className', 'style', 'selected_style', 'loading_state'),
        package = 'dashCoreComponents'
        )

    structure(component, class = c('dash_component', 'list'))
}
